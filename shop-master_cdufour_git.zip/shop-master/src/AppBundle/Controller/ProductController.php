<?php
namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

use AppBundle\Entity\Product;
use AppBundle\Form\ProductType;

class ProductController extends Controller
{
	/**
	* @Route("/admin/products")
	*/
	public function indexAction(Request $request)
	{
		// construction du formulaire d'ajout de produit
		$product = new Product();
		$form = $this->createForm(ProductType::class, $product);

		// alimente automatiquement les champs du formulaire
		// avec les données provenant de $request (POST)
		$form->handleRequest($request);

		if ($form->isSubmitted()) {
			// si requête POST alors on enregistre les données postées

			// $form->getData() évite d'avoir à explorer le tableau
			// des données postées et remplir une à une les propriétés
			// de l'object $product
			$product = $form->getData();

			$category_id = $product->getCategory()->getId();
			$product->setCategory($category_id);

			$em = $this->getDoctrine()->getManager();
			$em->persist($product);
			$em->flush();
		}

		// on récupère l'ensemble des products pour les fournir au template
		$products = $this->getDoctrine()
			->getRepository('AppBundle:Product')
			->findAll();

		// on souhaite récupérer tous les produits ainsi que les media associés

		// getEntityManager lorsqu'on effectue la requête dans le repository
		$em = $this->getDoctrine()->getManager();
		$query = $em->createQuery('
			SELECT p FROM AppBundle:Product p
			JOIN AppBundle:Media m
			WHERE p.id = m.product
		');
		$products2 = $query->getResult();

		var_dump($products2);



		return $this->render('product/index.html.twig', array(
			'form' => $form->createView(),
			'products' => $products,
		));
	}

	/**
	* @Route("/admin/products/new")
	*/
	public function newAction(Request $request)
	{
		return new Response('new action'); // temporaire
	}

}

?>
