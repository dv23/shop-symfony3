<?php

namespace AppBundle\Controller;

use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

use AppBundle\Entity\Client;

/**
* @Route("/users")
*/
class ClientController extends Controller
{
    /**
     * @Route("/clients", name="clients")
     */
    public function indexAction()
    {
		$clients1 = [
			['name' => 'Client 1', 'age' => 78],
			['name' => 'Client 2', 'age' => 89],
			['name' => 'Client 3', 'age' => 36],
		];

		// interrogation de la db
		$clients = $this->getDoctrine()
			->getRepository('AppBundle:Client')
			->findAllSorted();

		return $this->render('client/index.html.twig', array(
			'title' => 'Liste de mes clients',
			'clients' => $clients,
		));
    }

	/**
	* @Route("/clients/new")
	* @Method("POST")
	*/
	public function newAction(Request $request)
	{
		// ** récupération des données posted **
		//var_dump($request);
		//var_dump($request->request);
		$params = $request->request->all(); // récupère tous les paramètres d'une
		// requête POST ; cf api.symfony.com

		//** Enregistrement du nouveau client **
		$client = new Client();
		$client->setName($params['name']);
		$client->setAge($params['age']);

		$em = $this->getDoctrine()->getManager();
		$em->persist($client);
		$em->flush();

		return $this->redirectToRoute('clients');
	}

	/**
	* @Route("/clients/{id}/delete", name="client_delete")
	*/
	public function deleteAction($id)
	{
		// récupération du client grâce à l'id
		$em = $this->getDoctrine()->getManager();
		$client = $em->getRepository('AppBundle:Client')->find($id);

		// suppression
		$em->remove($client);
		$em->flush();

		// retour à la liste des clients
		return $this->redirectToRoute('clients');
	}

	/**
	* @Route("/clients/form")
	*/
	public function formAction()
	{
		// générer un formulaire automatique à partir de l'Entity client
		// et le transmettre au template
		return $this->render('client/form.html.twig', array());
	}
}
