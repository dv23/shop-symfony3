<?php

namespace AppBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Component\HttpFoundation\Request;

use AppBundle\Entity\Category;

class CategoryController extends Controller
{
    /**
     * @Route("/admin/categories", name="category_list")
	 * @Method("GET")
     */
    public function indexAction()
    {
		// Récupération des données (categories)
		$categories = $this->getDoctrine()
			->getRepository('AppBundle:Category')
			->findAll();

		return $this->render('category/index.html.twig', array(
			'categories' => $categories,
		));
    }

	/**
	 * @Route("/admin/categories", name="category_new")
	 * @Method("POST")
	 */
	public function newAction(Request $request)
	{
		// instantiation de la classe Category
		$category = new Category();

		//Accès direct à la super globale (au tableau associatif) $_POST
		//$category->setName($_POST['name']);

		$params = $request->request->all();
		$category->setName($params['name']);
		$category->setUrl($params['url']);

		$em = $this->getDoctrine()->getManager();
		$em->persist($category);
		$em->flush();

		//return $this->render('category/index.html.twig', array());
		return $this->redirectToRoute('category_list');
	}

	/**
	* @Route("/admin/categories/{id}/edit", name="category_edit")
	*/
	public function editAction($id)
	{
		$category = $this->getDoctrine()
			->getRepository('AppBundle:Category')
			->find($id);

		return $this->render('category/edit.html.twig', array(
			'category' => $category,
		));
	}

	/**
	* @Route("/admin/categories/{id}/update", name="category_update")
	*/
	public function updateAction(Category $category, Request $request)
	//public function updateAction($id, Request $request)
	{
		// on récupère l'objet qu'on doit mettre à jour
		// variante 1; récupération "manuelle" de l'objet category grâce à l'id
		/*
		$category = $this->getDoctrine()
			->getRepository('AppBundle:Category')
			->find($id);
		*/

		// variante 2 : on fournit directement en entrée de la
		// méthode un object category. Symfony se charge de la récupération
		// des données grâce à l'id fournit dans la route


		$params = $request->request->all();
		$category->setName($params['name']);
		$category->setUrl($params['url']);

		$em = $this->getDoctrine()->getManager();
		$em->persist($category);
		$em->flush();

		return $this->redirectToRoute('category_list');
	}

	/**
	* @route("/admin/categories/{id}/delete", name="category_delete")
	*/
	public function deleteAction(Category $category)
	{
		$em = $this->getDoctrine()->getManager();
		$em->remove($category);
		$em->flush();

		return $this->redirectToRoute('category_list');
	}

}
